-- Active: 1740418668383@@127.0.0.1@3306@mysql
-- Script: scripts/create_schema.sql
CREATE DATABASE IF NOT EXISTS vetcare_db;
USE vetcare_db;


CREATE TABLE IF NOT EXISTS pessoa (
id INT AUTO_INCREMENT PRIMARY KEY,
nome VARCHAR(255) NOT NULL,
telefone VARCHAR(50),
email VARCHAR(255)
);


CREATE TABLE IF NOT EXISTS tutor (
id INT PRIMARY KEY,
endereco VARCHAR(255),
FOREIGN KEY (id) REFERENCES pessoa(id) ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS veterinario (
id INT PRIMARY KEY,
especialidade VARCHAR(100),
crm VARCHAR(100),
FOREIGN KEY (id) REFERENCES pessoa(id) ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS prescricao (
id INT AUTO_INCREMENT PRIMARY KEY,
descricao TEXT,
medicamentos TEXT
);


CREATE TABLE IF NOT EXISTS consulta (
id INT AUTO_INCREMENT PRIMARY KEY,
tutor_id INT NOT NULL,
veterinario_id INT NOT NULL,
nome_animal VARCHAR(100),
data_consulta DATETIME,
descricao TEXT,
prescricao_id INT,
FOREIGN KEY (tutor_id) REFERENCES tutor(id) ON DELETE CASCADE,
FOREIGN KEY (veterinario_id) REFERENCES veterinario(id) ON DELETE SET NULL,
FOREIGN KEY (prescricao_id) REFERENCES prescricao(id) ON DELETE SET NULL
);